Tran Huu Nhan - 521H0507

cau 1: task1.ipynb
cau 2: lung_prediction.ipynb
data: cancer patient data sets.csv

gitHub source code: https://github.com/thnhan2/ml_tdtu_final.git
